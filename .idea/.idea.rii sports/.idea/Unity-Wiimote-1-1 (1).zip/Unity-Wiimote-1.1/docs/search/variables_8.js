var searchData=
[
  ['serial_5fnumber',['serial_number',['../structhid__device__info.html#a98b8efdc7b704502b747f75c544e1275',1,'hid_device_info']]]
];
