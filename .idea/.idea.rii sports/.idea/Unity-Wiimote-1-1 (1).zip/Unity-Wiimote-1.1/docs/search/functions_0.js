var searchData=
[
  ['acceldata',['AccelData',['../class_wiimote_api_1_1_accel_data.html#a2d3a9e84087aa3036fdf422b46cbcf12',1,'WiimoteApi::AccelData']]],
  ['activatewiimotionplus',['ActivateWiiMotionPlus',['../class_wiimote_api_1_1_wiimote.html#a9fd9946ab65cee566dccc328c093be90',1,'WiimoteApi::Wiimote']]]
];
