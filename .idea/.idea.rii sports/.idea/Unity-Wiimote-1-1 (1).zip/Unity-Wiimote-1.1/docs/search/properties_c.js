var searchData=
[
  ['r',['r',['../class_wiimote_api_1_1_wii_u_pro_data.html#a932b18201bb5855c78442a2713fdb5af',1,'WiimoteApi::WiiUProData']]],
  ['rawextension',['RawExtension',['../class_wiimote_api_1_1_wiimote.html#ac36df49363befe1d898cab0c07aef05d',1,'WiimoteApi::Wiimote']]],
  ['rollslow',['RollSlow',['../class_wiimote_api_1_1_motion_plus_data.html#a2b2dbdd9b4209d7c1775ccda2dc0be81',1,'WiimoteApi::MotionPlusData']]],
  ['rollspeed',['RollSpeed',['../class_wiimote_api_1_1_motion_plus_data.html#a6e7436dd5da5f38e6b69b3e2a782bf0a',1,'WiimoteApi::MotionPlusData']]],
  ['rstick',['rstick',['../class_wiimote_api_1_1_classic_controller_data.html#a3275b7ff8c14dfcb5236805451149481',1,'WiimoteApi.ClassicControllerData.rstick()'],['../class_wiimote_api_1_1_wii_u_pro_data.html#a6417e25683b640a3302a0d1b9d9cabf2',1,'WiimoteApi.WiiUProData.rstick()']]],
  ['rstick_5fbutton',['rstick_button',['../class_wiimote_api_1_1_wii_u_pro_data.html#a96e18ad788d683b666306ba726a9046b',1,'WiimoteApi::WiiUProData']]],
  ['rtrigger_5frange',['rtrigger_range',['../class_wiimote_api_1_1_classic_controller_data.html#ab9fc5563c57daca05f3fa03ad34702ce',1,'WiimoteApi::ClassicControllerData']]],
  ['rtrigger_5fswitch',['rtrigger_switch',['../class_wiimote_api_1_1_classic_controller_data.html#ada75fb3ed07f1ea4aec0b95b70dc4342',1,'WiimoteApi::ClassicControllerData']]]
];
