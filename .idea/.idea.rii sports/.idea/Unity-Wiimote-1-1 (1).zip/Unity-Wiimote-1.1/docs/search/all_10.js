var searchData=
[
  ['two',['two',['../class_wiimote_api_1_1_button_data.html#a424a42693728586a76baffe189e5e2c5',1,'WiimoteApi::ButtonData']]],
  ['type',['Type',['../class_wiimote_api_1_1_wiimote.html#a176612d0f1d02ebe6fb531f63f589449',1,'WiimoteApi::Wiimote']]]
];
