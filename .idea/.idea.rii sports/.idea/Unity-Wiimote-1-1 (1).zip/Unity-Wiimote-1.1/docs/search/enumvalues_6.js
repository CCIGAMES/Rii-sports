var searchData=
[
  ['ir_5fcamera_5fenable',['IR_CAMERA_ENABLE',['../namespace_wiimote_api.html#ab1429401f426b4ac4489dc034126616da2e50822bccbe193840eedf6fc51ce8c2',1,'WiimoteApi']]],
  ['ir_5fcamera_5fenable_5f2',['IR_CAMERA_ENABLE_2',['../namespace_wiimote_api.html#ab1429401f426b4ac4489dc034126616da40c38e7ce8408727ef1b3c24aa740675',1,'WiimoteApi']]]
];
