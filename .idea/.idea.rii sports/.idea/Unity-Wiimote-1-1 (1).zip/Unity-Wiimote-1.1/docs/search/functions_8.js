var searchData=
[
  ['motionplusdata',['MotionPlusData',['../class_wiimote_api_1_1_motion_plus_data.html#ae34b1f8aa36004899715aa655e652f2f',1,'WiimoteApi::MotionPlusData']]]
];
