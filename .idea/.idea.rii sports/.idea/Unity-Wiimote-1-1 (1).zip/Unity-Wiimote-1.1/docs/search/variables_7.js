var searchData=
[
  ['release_5fnumber',['release_number',['../structhid__device__info.html#afa3e33475ba1ca22de04710ae3b58e88',1,'hid_device_info']]],
  ['rumbleon',['RumbleOn',['../class_wiimote_api_1_1_wiimote.html#a710148cb091b53c252ab7845dfc84c62',1,'WiimoteApi::Wiimote']]]
];
