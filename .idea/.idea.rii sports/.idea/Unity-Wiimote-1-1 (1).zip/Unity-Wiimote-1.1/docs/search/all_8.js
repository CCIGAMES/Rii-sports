var searchData=
[
  ['inputdatatype',['InputDataType',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfd',1,'WiimoteApi']]],
  ['interface_5fnumber',['interface_number',['../structhid__device__info.html#a427f4738faf722f6c198a32bdaba9b49',1,'hid_device_info']]],
  ['interpretdata',['InterpretData',['../class_wiimote_api_1_1_accel_data.html#acdfab885b4909c5ff457dfb85827efc0',1,'WiimoteApi.AccelData.InterpretData()'],['../class_wiimote_api_1_1_button_data.html#ac9add2f4c5f2316aa7f48a554749cd0b',1,'WiimoteApi.ButtonData.InterpretData()'],['../class_wiimote_api_1_1_classic_controller_data.html#ab3d4c1aa2ea1d0ea1d8ce1c1c9b020d8',1,'WiimoteApi.ClassicControllerData.InterpretData()'],['../class_wiimote_api_1_1_i_r_data.html#a2dbf5e6095aac45c3e0239c0d537681f',1,'WiimoteApi.IRData.InterpretData()'],['../class_wiimote_api_1_1_motion_plus_data.html#a561794945b32fbf987852e2cd92e1573',1,'WiimoteApi.MotionPlusData.InterpretData()'],['../class_wiimote_api_1_1_nunchuck_data.html#aea42d1f6f8e26f9c45a4e9f26bc4bc28',1,'WiimoteApi.NunchuckData.InterpretData()'],['../class_wiimote_api_1_1_status_data.html#ae2d15db4cda38d012f9c8c522ce6403a',1,'WiimoteApi.StatusData.InterpretData()'],['../class_wiimote_api_1_1_wiimote_data.html#a3f7f4a9a99cb82e2966c6b51074af2ad',1,'WiimoteApi.WiimoteData.InterpretData()'],['../class_wiimote_api_1_1_wii_u_pro_data.html#a91889a3a4bdce8f65516b0ef5b091017',1,'WiimoteApi.WiiUProData.InterpretData()']]],
  ['interpretdatainterleaved',['InterpretDataInterleaved',['../class_wiimote_api_1_1_accel_data.html#a27064743f2e542e97b697c977b8cd562',1,'WiimoteApi.AccelData.InterpretDataInterleaved()'],['../class_wiimote_api_1_1_i_r_data.html#a962907af2859df7ab2f21ca326106d05',1,'WiimoteApi.IRData.InterpretDataInterleaved()']]],
  ['inttobigendian',['IntToBigEndian',['../class_wiimote_api_1_1_wiimote.html#af6074b6a555520ed73a75623cacd9e52',1,'WiimoteApi::Wiimote']]],
  ['ir',['Ir',['../class_wiimote_api_1_1_wiimote.html#a5607e7700f78a9159ff895530d92ec57',1,'WiimoteApi.Wiimote.Ir()'],['../class_wiimote_api_1_1_i_r_data.html#a114af030a9a10d1e9b38e576eecdd3e8',1,'WiimoteApi.IRData.ir()']]],
  ['ir_5fcamera_5fenable',['IR_CAMERA_ENABLE',['../namespace_wiimote_api.html#ab1429401f426b4ac4489dc034126616da2e50822bccbe193840eedf6fc51ce8c2',1,'WiimoteApi']]],
  ['ir_5fcamera_5fenable_5f2',['IR_CAMERA_ENABLE_2',['../namespace_wiimote_api.html#ab1429401f426b4ac4489dc034126616da40c38e7ce8408727ef1b3c24aa740675',1,'WiimoteApi']]],
  ['ir_5fenabled',['ir_enabled',['../class_wiimote_api_1_1_status_data.html#ae4a7022cefa8740a4f2c87e284b2a535',1,'WiimoteApi::StatusData']]],
  ['irdata',['IRData',['../class_wiimote_api_1_1_i_r_data.html',1,'WiimoteApi']]],
  ['irdata',['IRData',['../class_wiimote_api_1_1_i_r_data.html#ae66b703e8ff1bfe56f19edae301c85aa',1,'WiimoteApi::IRData']]],
  ['irdata_2ecs',['IRData.cs',['../_i_r_data_8cs.html',1,'']]],
  ['irdatatype',['IRDataType',['../namespace_wiimote_api.html#a9549244c36e3618c8a2387020b805289',1,'WiimoteApi']]]
];
