var searchData=
[
  ['outputdatatype',['OutputDataType',['../namespace_wiimote_api.html#ab1429401f426b4ac4489dc034126616d',1,'WiimoteApi']]]
];
