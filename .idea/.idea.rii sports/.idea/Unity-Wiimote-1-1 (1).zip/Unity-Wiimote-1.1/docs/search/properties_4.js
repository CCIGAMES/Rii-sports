var searchData=
[
  ['ext_5fconnected',['ext_connected',['../class_wiimote_api_1_1_status_data.html#a8bdca92c52d71c510ac54315874c49eb',1,'WiimoteApi::StatusData']]],
  ['extensionconnected',['ExtensionConnected',['../class_wiimote_api_1_1_motion_plus_data.html#a6b47ab39fe21379720d9b3f4d7bb9c3b',1,'WiimoteApi::MotionPlusData']]]
];
