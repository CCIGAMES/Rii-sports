var searchData=
[
  ['read_5fmemory_5fregisters',['READ_MEMORY_REGISTERS',['../namespace_wiimote_api.html#ab1429401f426b4ac4489dc034126616da6a9f977d32d3df7ad080827cb0b56c8f',1,'WiimoteApi.READ_MEMORY_REGISTERS()'],['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfda6a9f977d32d3df7ad080827cb0b56c8f',1,'WiimoteApi.READ_MEMORY_REGISTERS()']]],
  ['report_5fbuttons',['REPORT_BUTTONS',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfda8c99859de6a05b3c6bc3f0ecfa0f1ec3',1,'WiimoteApi']]],
  ['report_5fbuttons_5faccel',['REPORT_BUTTONS_ACCEL',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfda86af183069fa7ba298163d18d08abd66',1,'WiimoteApi']]],
  ['report_5fbuttons_5faccel_5fext16',['REPORT_BUTTONS_ACCEL_EXT16',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfda173ca2fcbbf5111d139a452b2471b7a4',1,'WiimoteApi']]],
  ['report_5fbuttons_5faccel_5fir10_5fext6',['REPORT_BUTTONS_ACCEL_IR10_EXT6',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfda6dc1a00d4d94a66509f266053f93a42c',1,'WiimoteApi']]],
  ['report_5fbuttons_5faccel_5fir12',['REPORT_BUTTONS_ACCEL_IR12',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfda794fa75b3a346ff175429a9284892a8d',1,'WiimoteApi']]],
  ['report_5fbuttons_5fext19',['REPORT_BUTTONS_EXT19',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfda7e4ac87457ab44d3597879da1cd52706',1,'WiimoteApi']]],
  ['report_5fbuttons_5fext8',['REPORT_BUTTONS_EXT8',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfdacebd2ea6e634a0aa5de27c9d6b548092',1,'WiimoteApi']]],
  ['report_5fbuttons_5fir10_5fext9',['REPORT_BUTTONS_IR10_EXT9',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfdac4a4f6f0092bc44d3bce8ec53dc40f0d',1,'WiimoteApi']]],
  ['report_5fext21',['REPORT_EXT21',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfda8976741fe52a0a5bc7a69dc2b43a55f1',1,'WiimoteApi']]],
  ['report_5finterleaved',['REPORT_INTERLEAVED',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfdac93ca9c80c9c7fbcaa0e1e2860f400a5',1,'WiimoteApi']]],
  ['report_5finterleaved_5falt',['REPORT_INTERLEAVED_ALT',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfda66cb55e00377759d8a5d46e8c0d21056',1,'WiimoteApi']]]
];
