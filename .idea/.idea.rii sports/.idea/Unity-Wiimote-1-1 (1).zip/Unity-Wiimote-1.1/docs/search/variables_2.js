var searchData=
[
  ['interface_5fnumber',['interface_number',['../structhid__device__info.html#a427f4738faf722f6c198a32bdaba9b49',1,'hid_device_info']]]
];
