var searchData=
[
  ['calibrateaccel',['CalibrateAccel',['../class_wiimote_api_1_1_accel_data.html#aa737f0bb1a4dce36423d19a6c5079120',1,'WiimoteApi::AccelData']]],
  ['classiccontrollerdata',['ClassicControllerData',['../class_wiimote_api_1_1_classic_controller_data.html#adf8447fc2b35bdc453e6793b42b9fc73',1,'WiimoteApi::ClassicControllerData']]],
  ['cleanup',['Cleanup',['../class_wiimote_api_1_1_wiimote_manager.html#a7e511f348127acf03ef8b3cbc30971ce',1,'WiimoteApi::WiimoteManager']]]
];
