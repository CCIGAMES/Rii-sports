var searchData=
[
  ['deactivatewiimotionplus',['DeactivateWiiMotionPlus',['../class_wiimote_api_1_1_wiimote.html#ab947442ac726dbe7383b4abd0b9cd97f',1,'WiimoteApi::Wiimote']]]
];
