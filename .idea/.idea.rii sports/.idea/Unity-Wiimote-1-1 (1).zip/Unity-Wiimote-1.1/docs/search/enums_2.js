var searchData=
[
  ['inputdatatype',['InputDataType',['../namespace_wiimote_api.html#a30df65e3a4b95c646e296ce514167dfd',1,'WiimoteApi']]],
  ['irdatatype',['IRDataType',['../namespace_wiimote_api.html#a9549244c36e3618c8a2387020b805289',1,'WiimoteApi']]]
];
