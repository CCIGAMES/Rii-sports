var searchData=
[
  ['nunchuckdata',['NunchuckData',['../class_wiimote_api_1_1_nunchuck_data.html#a41f9ddb63f6b607077ed5edd46948f83',1,'WiimoteApi::NunchuckData']]]
];
