var searchData=
[
  ['hid_5fdevice_5finfo',['hid_device_info',['../structhid__device__info.html',1,'']]],
  ['hidapi',['HIDapi',['../class_h_i_dapi.html',1,'']]]
];
