var searchData=
[
  ['usage',['usage',['../structhid__device__info.html#a92ee34b80532eb9ba50bcacd66c1b0a4',1,'hid_device_info']]],
  ['usage_5fpage',['usage_page',['../structhid__device__info.html#a83fb0fc16f5c233ccf6dd66950147f5b',1,'hid_device_info']]]
];
