var searchData=
[
  ['basic',['BASIC',['../namespace_wiimote_api.html#a9549244c36e3618c8a2387020b805289ae4ac03f6c9f00665644e868dd1fb9f1e',1,'WiimoteApi']]]
];
