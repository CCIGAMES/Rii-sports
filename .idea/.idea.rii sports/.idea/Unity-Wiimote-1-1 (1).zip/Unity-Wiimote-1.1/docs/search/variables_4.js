var searchData=
[
  ['next',['next',['../structhid__device__info.html#a05e0d3bb23460a477b32336321700b61',1,'hid_device_info']]]
];
