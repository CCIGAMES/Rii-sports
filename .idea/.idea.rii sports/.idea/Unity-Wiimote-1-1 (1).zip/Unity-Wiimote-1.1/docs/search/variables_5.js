var searchData=
[
  ['owner',['Owner',['../class_wiimote_api_1_1_wiimote_data.html#a1e02de970532af49a657113006d82d66',1,'WiimoteApi::WiimoteData']]]
];
