var searchData=
[
  ['pitchslow',['PitchSlow',['../class_wiimote_api_1_1_motion_plus_data.html#ae744a62f38413f43d3293c66602cd9bf',1,'WiimoteApi::MotionPlusData']]],
  ['pitchspeed',['PitchSpeed',['../class_wiimote_api_1_1_motion_plus_data.html#a6d1e0681d149327c7e8e55c27e5c29c9',1,'WiimoteApi::MotionPlusData']]],
  ['plus',['plus',['../class_wiimote_api_1_1_button_data.html#a53945bd189c265fb7e7f2d446c60592a',1,'WiimoteApi.ButtonData.plus()'],['../class_wiimote_api_1_1_classic_controller_data.html#a74b50e34b589a0deedc4d2607e7cb769',1,'WiimoteApi.ClassicControllerData.plus()'],['../class_wiimote_api_1_1_wii_u_pro_data.html#ac5836622296247f722df1c37327e37df',1,'WiimoteApi.WiiUProData.plus()']]]
];
