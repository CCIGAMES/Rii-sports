var searchData=
[
  ['motionplus',['MOTIONPLUS',['../namespace_wiimote_api.html#a11c9a1c61a7e37bd5dce2f6f89623bd2af46e387e25e93b43c4e9c462d8ea9b8e',1,'WiimoteApi']]],
  ['motionplus_5fclassic',['MOTIONPLUS_CLASSIC',['../namespace_wiimote_api.html#a11c9a1c61a7e37bd5dce2f6f89623bd2aac198c06c52c31ac435ab6d2112395fc',1,'WiimoteApi']]],
  ['motionplus_5fnunchuck',['MOTIONPLUS_NUNCHUCK',['../namespace_wiimote_api.html#a11c9a1c61a7e37bd5dce2f6f89623bd2a2dd77c8fe1df79727c487a5395493dda',1,'WiimoteApi']]]
];
