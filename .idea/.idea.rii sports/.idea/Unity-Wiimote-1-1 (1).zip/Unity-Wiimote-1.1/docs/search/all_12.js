var searchData=
[
  ['vendor_5fid',['vendor_id',['../structhid__device__info.html#ab2685aa9bfb4db9e16f5139f97a64ba0',1,'hid_device_info']]]
];
