var searchData=
[
  ['registertype',['RegisterType',['../namespace_wiimote_api.html#a334f23b8e03899251065988e3dd26d7c',1,'WiimoteApi']]]
];
