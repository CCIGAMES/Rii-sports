var searchData=
[
  ['manufacturer_5fstring',['manufacturer_string',['../structhid__device__info.html#a29c048d0e0cfc3b84a752fb069e7117d',1,'hid_device_info']]],
  ['maxwritefrequency',['MaxWriteFrequency',['../class_wiimote_api_1_1_wiimote_manager.html#a27efbbd4780dd98ff2b13e600f823e3f',1,'WiimoteApi::WiimoteManager']]]
];
