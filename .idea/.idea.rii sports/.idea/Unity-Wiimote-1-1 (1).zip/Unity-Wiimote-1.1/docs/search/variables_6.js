var searchData=
[
  ['path',['path',['../structhid__device__info.html#a32907be997439c973012482cc4e269a4',1,'hid_device_info']]],
  ['product_5fid',['product_id',['../structhid__device__info.html#ac750ec218ca62bd2072b5d96ce29102e',1,'hid_device_info']]],
  ['product_5fstring',['product_string',['../structhid__device__info.html#a8f88372e7876c0d4f03bbceda303e69b',1,'hid_device_info']]]
];
