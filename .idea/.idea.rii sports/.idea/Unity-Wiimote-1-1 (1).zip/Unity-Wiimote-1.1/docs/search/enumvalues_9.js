var searchData=
[
  ['none',['NONE',['../namespace_wiimote_api.html#a11c9a1c61a7e37bd5dce2f6f89623bd2ab50339a10e1de285ac99d4c3990b8693',1,'WiimoteApi']]],
  ['nunchuck',['NUNCHUCK',['../namespace_wiimote_api.html#a11c9a1c61a7e37bd5dce2f6f89623bd2ac2e8c02a9cd4b69c2c18d350072e6ad5',1,'WiimoteApi']]]
];
