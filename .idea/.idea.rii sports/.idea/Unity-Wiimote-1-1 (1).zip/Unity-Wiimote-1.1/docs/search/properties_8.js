var searchData=
[
  ['minus',['minus',['../class_wiimote_api_1_1_button_data.html#a50a5d3125dd0713d497d1314ecf3891c',1,'WiimoteApi.ButtonData.minus()'],['../class_wiimote_api_1_1_classic_controller_data.html#ae2229aef5823fa0063016479d879043f',1,'WiimoteApi.ClassicControllerData.minus()'],['../class_wiimote_api_1_1_wii_u_pro_data.html#ad5386dc8335bc0e45013caf715564d3c',1,'WiimoteApi.WiiUProData.minus()']]],
  ['motionplus',['MotionPlus',['../class_wiimote_api_1_1_wiimote.html#afccc80f4161e0d960544bccca600e5e5',1,'WiimoteApi::Wiimote']]]
];
