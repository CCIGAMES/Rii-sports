var searchData=
[
  ['ir',['Ir',['../class_wiimote_api_1_1_wiimote.html#a5607e7700f78a9159ff895530d92ec57',1,'WiimoteApi.Wiimote.Ir()'],['../class_wiimote_api_1_1_i_r_data.html#a114af030a9a10d1e9b38e576eecdd3e8',1,'WiimoteApi.IRData.ir()']]],
  ['ir_5fenabled',['ir_enabled',['../class_wiimote_api_1_1_status_data.html#ae4a7022cefa8740a4f2c87e284b2a535',1,'WiimoteApi::StatusData']]]
];
