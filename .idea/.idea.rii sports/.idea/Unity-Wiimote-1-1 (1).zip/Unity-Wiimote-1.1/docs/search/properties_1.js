var searchData=
[
  ['b',['b',['../class_wiimote_api_1_1_button_data.html#a1a1cd0c1985fb30e0b24887919b44fd5',1,'WiimoteApi.ButtonData.b()'],['../class_wiimote_api_1_1_classic_controller_data.html#ab009c6a19b2cfeca1f6fc51a507a5fe5',1,'WiimoteApi.ClassicControllerData.b()'],['../class_wiimote_api_1_1_wii_u_pro_data.html#a4031d54ee0f8644affcbd512f9f5d3c5',1,'WiimoteApi.WiiUProData.b()']]],
  ['battery_5flevel',['battery_level',['../class_wiimote_api_1_1_status_data.html#a8ffcc167e1301e4003f2ddf59d1cf565',1,'WiimoteApi::StatusData']]],
  ['battery_5flow',['battery_low',['../class_wiimote_api_1_1_status_data.html#a3f8659f344fd7c50e43c685072d47b9a',1,'WiimoteApi::StatusData']]],
  ['button',['Button',['../class_wiimote_api_1_1_wiimote.html#ab68c3011f8b13267af576c29ec6681e9',1,'WiimoteApi::Wiimote']]]
];
