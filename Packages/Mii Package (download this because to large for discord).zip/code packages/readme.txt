this is all ready built as an exe to test if its good, it is unity code and 
using the mii body models instead of the default unity rig model should work