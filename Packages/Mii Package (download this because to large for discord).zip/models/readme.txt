they dont have heads because you customise the heads and face so we will have to make a head
 and rig it up to show other peoples miis when in a multiplayer match, which is most of the sports
and there will be npc bosses for when a player gains a high enough level, like the mii called matt
ill send you some models for the npc bosses you can rig up these models with mixamo